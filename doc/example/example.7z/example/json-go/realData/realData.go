package realdata

type RealData struct {
	S     S     `json:"S"`
	Name0 int64 `json:"name0"`
}

type S struct {
	A     []A  `json:"A"`
	Name1 bool `json:"name1"`
}

type A struct {
	Name2 int64  `json:"name2"`
	Name3 string `json:"name3"`
}
