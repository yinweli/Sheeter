namespace realdata
{
    using System;
    using System.Collections.Generic;

    using System.Globalization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    public partial class RealData
    {
        [JsonProperty("S")]
        public S S { get; set; }

        [JsonProperty("name0")]
        public long Name0 { get; set; }
    }

    public partial class S
    {
        [JsonProperty("A")]
        public A[] A { get; set; }

        [JsonProperty("name1")]
        public bool Name1 { get; set; }
    }

    public partial class A
    {
        [JsonProperty("name2")]
        public long Name2 { get; set; }

        [JsonProperty("name3")]
        public string Name3 { get; set; }
    }
}
